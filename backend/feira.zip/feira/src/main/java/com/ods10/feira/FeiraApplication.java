package com.ods10.feira;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeiraApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeiraApplication.class, args);
	}

}
